<div class="relative bg-black text-white">
  <div class="absolute inset-0">
    <div class="absolute inset-0 bg-gradient-to-t md:bg-gradient-to-r from-black via-black to-transparent opacity-90"></div>
    <?php echo wp_get_attachment_image(
                get_post_thumbnail_id(),
                'full',
                false,
                ['alt' => 'LPPI','class' => 'object-cover w-full h-full']
            ); ?>
  </div>
  <div class="relative">
    <div class="pt-12 pb-12 md:pb-16 flex items-end md:items-center">
      <div class="container">
        <div class="h-40"></div>
        <div class="md:w-2/3 space-y-4 pb-8 md:pb-0">
          <?php echo $__env->first(['components.eyebrow-'.get_post_type(), 'components.eyebrow'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <h1 class="tracking-tight font-bold text-4xl md:text-5xl xl:text-6xl 2xl:text-7xl leading-none font-primary-a uppercase">
            <?= get_the_title(); ?>
          </h1>
          <div class="prose opacity-80"><?php the_excerpt(); ?></div>
          <?php echo $__env->make('components.button-animated-top',[
            'cta'     =>'Read More', 
            'classes' =>'text-white', 
            'url'     => get_permalink()
          ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
      </div>
    </div>
  </div>
</div><?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/lppi/resources/views/components/item-hero.blade.php ENDPATH**/ ?>