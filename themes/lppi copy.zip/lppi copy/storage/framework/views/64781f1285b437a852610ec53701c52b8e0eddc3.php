<?php extract([
  'imageid'     => $imageid ?? false,
  'imagesize'   => $imagesize ?? 'large',
  'imageclass'  => $imageclass ?? 'w-full h-full object-cover',
]); ?>
<?php if($imageid): ?>
  <?php echo wp_get_attachment_image(
                $imageid,
                $imagesize,
                false,
                ['alt' => 'LPPI','class' => $imageclass ]
            ); ?>    
<?php endif; ?><?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/latinopolicy/resources/views/components/image.blade.php ENDPATH**/ ?>