<a data-aos="fade-up" href="<?= get_permalink(); ?>" class="block group space-y-2">
  <div class="aspect-w-4 aspect-h-5 bg-black transition ease relative">
    <div class="absolute inset-0 group-hover:opacity-75 transition ease duration-500 opacity-95">
      <?php echo wp_get_attachment_image(
                get_post_thumbnail_id(),
                'full',
                false,
                ['alt' => ' ','class' => 'object-cover w-full h-full']
            ); ?>
    </div>
  </div>
  <div class="space-y-px font-medium">
    
    
    <div class="text-brand-dark"><?= get_the_title(); ?></div>
    <div class="text-sm text-gray-500"><?= get_field('title'); ?></div>
  </div>
</a><?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/lppi/resources/views/components/item-people.blade.php ENDPATH**/ ?>