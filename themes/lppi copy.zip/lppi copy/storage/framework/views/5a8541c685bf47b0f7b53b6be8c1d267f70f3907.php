<?php if (get_field('content')) : ?>
  <div class="container">
    <ul class="space-y-8 md:space-y-12 xl:space-y-20">
      <?php $i = 1; ?>
      <?php if (have_rows('content')) : ?><?php while (have_rows('content')) : the_row(); ?>
        <?php echo $__env->make('components.image-text', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php $i++ ?>
      <?php endwhile; endif; ?>
    </ul>
  </div>
<?php endif; ?><?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/latinopolicy/resources/views/partials/page-blocks.blade.php ENDPATH**/ ?>