<div class="container py-6 md:py-10 grid grid-cols-2 gap-4 md:gap-6">
  <div class="space-y-4">
    <div class="prose md:prose-lg lg:prose-xl max-w-full">
      <h1 class="uppercase font-primary-a text-brand-darker uppercase tracking-tight"><?php echo e($item->label); ?></h1>
    </div>
    <div class="prose prose-sm sm:prose">
      <p><?php echo get_the_excerpt($item->objectId); ?></p>
    </div>
    <div>
      <?php echo $__env->make('components.button-animated',[
        'cta'      =>'Learn More', 
        'classes'  =>'',
        'url'      => get_the_permalink($item->objectId)
      ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </div>
  <div class="pt-2">
    <ul class="grid grid-cols-2 gap-2 md:gap-4">
      <?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="block my-child-item <?php echo e($child->classes ?? ''); ?> <?php echo e($child->active ? 'active' : ''); ?>">
          <a href="<?php echo e($child->url); ?>" class="font-medium text-brand-dark block flex border rounded items-center hover:shadow-xl transition ease duration-500">
            <?php $image = get_field('icon', $child->objectId); ?>
            <div class="w-20 h-20 flex-none flex items-center justify-center">
              <?php if($image): ?>
                <div class="py-2 px-4">
                  <?php echo wp_get_attachment_image(
                $image,
                'thumbnail',
                false,
                ['alt' => 'LPPI','class' => 'object-cover w-full h-full']
            ); ?>
                </div>
              <?php else: ?>
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                </svg>
              <?php endif; ?>
            </div>
            <span class="pr-4 leading-tight"><?php echo $child->label; ?></span>
          </a>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
</div>
<?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/latinopolicy/resources/views/components/menu-content.blade.php ENDPATH**/ ?>