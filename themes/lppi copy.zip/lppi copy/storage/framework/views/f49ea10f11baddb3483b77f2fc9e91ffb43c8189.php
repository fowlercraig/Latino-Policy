<?php extract([
  'classes' => $classes ?? 'bg-gray-100',
]); ?>

<hr class="border-0 h-px <?php echo e($classes); ?>" /><?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/latinopolicy/resources/views/components/divider.blade.php ENDPATH**/ ?>