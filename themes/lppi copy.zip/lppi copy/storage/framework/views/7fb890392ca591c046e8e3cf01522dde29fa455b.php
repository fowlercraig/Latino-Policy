<div class="bg-brand h-8 px-3 inline-flex items-center text-white space-x-1 text-xs sm:text-sm font-medium">
  
  <?php if(has_term('','issue')): ?>
    <span><?php if (get_the_terms(get_the_ID(), 'issue')) : ?><?= collect(get_the_terms(get_the_ID(), 'issue'))->shift()->name; ?><?php endif; ?></span>
  <?php else: ?>
    <span>News &amp; Press</span>
  <?php endif; ?>

</div><?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/latinopolicy/resources/views/components/eyebrow-press.blade.php ENDPATH**/ ?>