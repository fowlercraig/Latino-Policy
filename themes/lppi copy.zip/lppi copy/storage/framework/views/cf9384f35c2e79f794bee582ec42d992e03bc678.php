<?php if (! empty($post->post_parent)) : ?>
  <?php $parent = $post->post_parent; ?>
  <?php if($parent): ?>
    <div class="font-medium prose">
      <a href="<?= get_permalink($parent); ?>" class="group transition ease duration-300">
        <span class="text-brand-lighter group-hover:text-white transition ease duration-300 group-hover:-ml-1">&larr;</span>
        <span class="text-brand-lighter group-hover:text-white transition ease duration-300">Back to <?= get_the_title($parent); ?></span>
      </a>
    </div>
  <?php endif; ?>
<?php endif; ?><?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/latinopolicy/resources/views/partials/page-header-child.blade.php ENDPATH**/ ?>