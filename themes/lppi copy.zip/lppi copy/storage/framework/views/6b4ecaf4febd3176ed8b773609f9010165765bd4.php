<?php $__env->startSection('content'); ?>
  
  <?php echo $__env->make('partials.list-hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
  <div class="h-2"></div>
  
  <?php echo $__env->make('partials.mission-banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
  <div class="h-2"></div>
  
  <?php echo $__env->make('partials.list-research',['title'=>'Recent Projects & Reports', 'limit'=>4], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
  <div class="h-0 md:h-12 xl:h-20"></div>
  
  <?php echo $__env->make('partials.banner-vrp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
  <div class="h-5 md:h-12 xl:h-20"></div>
  
  <?php echo $__env->make('partials.list-news', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
  <div class="h-5 md:h-12 xl:h-20"></div>
  
  <?php echo $__env->make('partials.banner-donate',[
    'title' => get_field('donate_eyebrow'),
    'desc'  => get_field('donate_content')
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
  <?php echo $__env->make('partials.modal-subscribe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/latinopolicy/resources/views/front-page.blade.php ENDPATH**/ ?>