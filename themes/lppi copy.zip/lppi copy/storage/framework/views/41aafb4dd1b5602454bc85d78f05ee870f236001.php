<?php extract([
  'url'     => $url ?? false,
  'classes' => $classes ?? false,
  'target'  => $target ?? '_self',
  'group'   => $group ?? false,
  'span'   => $span ?? false,
  'cta'     => $cta ?? 'Call to Action',
]); ?>

<?php if($span): ?>
<span class="font-medium inline-block space-y-1 group text-sm sm:text-base no-underline <?php echo e($classes); ?>">
<?php else: ?>
<a class="font-medium inline-block space-y-1 group text-sm sm:text-base no-underline <?php echo e($classes); ?>" href="<?php echo e($url); ?>" target="<?php echo e($target); ?>">
<?php endif; ?>
  <span class="block order-last"><?php echo e($cta); ?></span>
  <div class="relative bg-brand-lighter">
    <span class="h-0.5 bg-transparent block relative"></span>
    <span class="h-0.5 bg-brand-darker block absolute bottom-0 w-0 group-hover:w-full transition-all ease duration-300"></span>
  </div>
<?php if($span): ?>
</span>
<?php else: ?>
</a>
<?php endif; ?><?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/lppi/resources/views/components/button-animated.blade.php ENDPATH**/ ?>