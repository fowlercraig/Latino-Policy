<?php $title = 'Voting Rights Project'; ?>
<?php $desc = '<p>The UCLA Voting Rights Project is the flagship project of the UCLA Latino Policy & Politics Initiative aimed at creating an accessible and equitable system of voting for all Americans through impact litigation, research, and clinical education to expand access to the ballot box.</p>'; ?>

<section>
  <div class="container pr-0 bg-black" data-aos="fade-up">
    <div class="text-white flex flex-wrap items-center">
      <div class="w-full lg:w-1/2 xl:w-1/3 md:order-last h-64 lg:h-auto">
        <?php echo wp_get_attachment_image(
                3549,
                'full',
                false,
                ['alt' => 'Voting Rights Project','class' => 'w-full h-full object-cover']
            ); ?>
      </div>
      <div class="w-full py-6 lg:py-0 lg:w-1/2 xl:w-2/3 space-y-4 ">
        <h1 class="tracking-tight font-bold text-4xl md:text-5xl 2xl:text-6xl leading-8 md:leading-none font-primary-a uppercase"><?php echo $title; ?></h1>
        <div class="h-0.5 w-32 bg-red-600"></div>
        <div class="prose opacity-75"><?php echo $desc; ?></div>
        <?php echo $__env->make('components.button-animated-top',[
          'cta'=>'Learn More', 
          'classes'=>'', 
          'url'=> get_permalink(3483)
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>
  </div>
</section><?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/lppi/resources/views/partials/banner-vrp.blade.php ENDPATH**/ ?>