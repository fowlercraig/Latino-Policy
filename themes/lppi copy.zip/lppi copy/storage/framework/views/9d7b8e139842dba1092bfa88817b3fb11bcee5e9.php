<?php extract([
  'ids'       => $ids ?? false,
  'tax'       => $tax ?? false,
  'limit'     => $limit ?? 4,
  'orderby'   => $orderby ?? 'date',
  'post_type' => $post_type ?? 'research',
]); ?>

<?php $tax_terms = null; ?>
<?php $meta_terms = null; ?>

<?php if($tax): ?>
  <?php $tax_terms = array(
    array(
      'taxonomy'  => 'issue',
      'field'     => 'slug',
      'terms'     => $tax,
    )
  ); ?>
<?php endif; ?>

<?php if(is_singular('people')): ?>
  <?php $meta_terms = array(
    array(
      'key'     => 'contributors',
      'value'   => '"' . get_the_ID() . '"',
      'compare' => 'LIKE'
    )
  ); ?>
<?php endif; ?>

<?php global $query; ?><?php $query = new WP_Query([
  'post_type'       => $post_type,
  'posts_per_page'  => $limit,
  'post__in'        => $ids,
  'tax_query'       => $tax_terms,
  'meta_query'      => $meta_terms,
  'orderby'         => $orderby,
  'order'           => 'DESC',
]); ?>

<?php if (empty($query)) : ?><?php global $wp_query; ?><?php $query = $wp_query; ?><?php endif; ?><?php if ($query->have_posts()) : ?>
  <section class="<?php if(is_front_page()): ?> bg-brand-lightest py-5 md:py-12 xl:py-20 <?php endif; ?>">
    <div class="container space-y-6">
      <?php echo $__env->make('components.section-header',['title'=>$title], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="grid lg:grid-cols-2 gap-4 md:gap-6 xl:gap-10">
        <?php if (empty($query)) : ?><?php global $wp_query; ?><?php $query = $wp_query; ?><?php endif; ?><?php if ($query->have_posts()) : ?><?php while ($query->have_posts()) : $query->the_post(); ?>
          <?php echo $__env->make('components.item-research', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endwhile; wp_reset_postdata(); endif; ?>
      </div>
    </div>
  </section>
<?php wp_reset_postdata(); endif; ?><?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/latinopolicy/resources/views/partials/list-research.blade.php ENDPATH**/ ?>