<div class="container">
  <div class="h-12 flex items-center justify-between">
    <ul class="nav-primary flex items-center">
      <?php if($navigation): ?>
        <?php $__currentLoopData = $navigation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="group" @mouseenter="menu=true " @mouseleave="menu = null">
            <a class="first:pl-0 px-3 lg:px-4 block flex lg:space-x-1 items-center relative hover:underline" href="<?php echo $item->url; ?>">
              <span class="font-karbon text-sm lg:text-nav uppercase tracking-wider"><?php echo $item->label; ?></span> 
              <?php if($item->children): ?>
                <i width="16px" height="16px" class="text-gray-300" data-feather="chevron-down"></i>
              <?php endif; ?>
            </a>
            <?php if($item->children): ?>
              <div class="bg-white p-6 absolute text-black border-b inset-x-0 hidden invisible opacity-0 transition ease duration-500 group-hover:block group-hover:visible group-hover:opacity-100">
                <?php echo $__env->make('components.menu-content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </div>
            <?php endif; ?>
          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </ul>
    <nav class="nav-primary flex items-center space-x-3 lg:space-x-4 text-sm">
      <?php echo $__env->make('partials.searchform', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php if(has_nav_menu('social_navigation')): ?>
        <ul class="flex items-center space-x-4 text-current">
          <?php $menuLocations = get_nav_menu_locations(); ?>
          <?php $menuID = $menuLocations['social_navigation']; ?>
          <?php $primaryNav = wp_get_nav_menu_items($menuID); ?>
          <?php $__currentLoopData = $primaryNav; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $navItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
              <a target="_blank" href="<?php echo e($navItem->url); ?>" title="<?php echo e($navItem->title); ?>">
                <i class="fab fa-<?php echo e(strtolower($navItem->title)); ?>"></i>
                <span class="sr-only"><?php echo e($navItem->title); ?></span>
              </a>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      <?php endif; ?>
    </nav>
  </div>
</div>
<?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/latinopolicy/resources/views/partials/navigation.blade.php ENDPATH**/ ?>