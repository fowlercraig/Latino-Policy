<?php global $query; ?><?php $query = new WP_Query([
  'post_type'       => array('research'),
  'post__in'        => get_field('carousel_carousel'),
  'posts_per_page'  => -1,
  'order'           => 'DESC',
]); ?>

<?php if (empty($query)) : ?><?php global $wp_query; ?><?php $query = $wp_query; ?><?php endif; ?><?php if ($query->have_posts()) : ?>
  <section class="relative bg-black">
    <div class="md:-mt-40 relative">
      <ul id="carousel" class="carousel">
        <?php if (empty($query)) : ?><?php global $wp_query; ?><?php $query = $wp_query; ?><?php endif; ?><?php if ($query->have_posts()) : ?><?php while ($query->have_posts()) : $query->the_post(); ?>
          <li><?php echo $__env->make('components.item-hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></li>
        <?php endwhile; wp_reset_postdata(); endif; ?>
      </ul>
    </div>
    <div class="absolute inset-x-0 bottom-0">
      <div class="container flex outline-none" id="carousel-controls">
        <?php $classes = 'h-12 w-12 md:h-10 md:w-10 flex items-center justify-center text-white bg-brand hover:bg-brand-dark transition transition ease-in-out duration-150 hover:scale-110'; ?>
        <button class="prev <?php echo e($classes); ?>"><i data-feather="chevron-left"></i></button>
        <button class="next <?php echo e($classes); ?>"><i data-feather="chevron-right"></i></button>
      </div>
    </div>
  </section>
<?php wp_reset_postdata(); endif; ?>


<?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/latinopolicy/resources/views/partials/list-hero.blade.php ENDPATH**/ ?>