<?php extract([
  'textColor' => $textColor ?? 'text-white opacity-75',
]); ?>

<?php $contributors = get_field('contributors'); ?>

<?php if($contributors): ?>
  <?php echo $__env->make('components.divider',['classes'=>'bg-white opacity-20'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <h3 class="font-medium text-sm <?php echo e($textColor); ?>">Contributors</h3>
  <div class="grid grid-cols-2 gap-2">
    <?php $__currentLoopData = $contributors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contributor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a href="<?= get_permalink($contributor); ?>" class="flex items-center">
        <?php $image = get_post_thumbnail_id($contributor); ?>
        <?php echo wp_get_attachment_image(
                $image,
                'thumbnail',
                false,
                ['alt' => 'My alt tag','class' => 'my-0 mr-4 w-10 h-10 rounded-full']
            ); ?>
        <div class="leading-tight text-sm">
          <span class="block font-medium <?php echo e($textColor); ?>"><?= get_the_title($contributor); ?></span>
          <span class="block font-medium text-xs"><?php if (get_the_terms($contributor, 'role')) : ?><?= collect(get_the_terms($contributor, 'role'))->shift()->name; ?><?php endif; ?></span>
        </div>
      </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
<?php endif; ?>
<?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/lppi/resources/views/components/entry-contributors.blade.php ENDPATH**/ ?>