<?php extract([
  'limit'   => $limit ?? 4,
  'posts'   => $posts ?? false,
  'desc'    => $desc ?? false,
  'role'    => $role ?? false,
  'tax'     => $tax ?? false,
  'orderby' => $orderby ?? 'menu_order',
]); ?>

<?php $tax_terms = null; ?>
<?php $currentPerson = null; ?>

<?php if($role): ?>
  <?php $tax_terms = array(
    array(
      'taxonomy' => 'role',
      'field' => 'slug',
      'terms' => $role,
    )
  ); ?>
<?php endif; ?>

<?php if($tax): ?>
  <?php $tax_terms = array(
    array(
      'taxonomy' => 'issue',
      'field' => 'slug',
      'terms' => $tax,
    )
  ); ?>
<?php endif; ?>

<?php if(is_singular('people')): ?>
  <?php $currentPerson = get_the_ID(); ?>
<?php endif; ?>


<?php if($posts): ?>
  <?php global $query; ?><?php $query = new WP_Query([
    'post_type'       => array('people'),
    'posts_per_page'  => $limit,
    'post__in'        => $posts,
    'order'           => 'ASC',
    'orderby'         => $orderby,
  ]); ?>
<?php else: ?>
  <?php global $query; ?><?php $query = new WP_Query([
    'post_type'       => array('people'),
    'posts_per_page'  => $limit,
    'post__not_in'    => array($currentPerson),
    'order'           => 'ASC',
    'orderby'         => $orderby,
    'tax_query'       => $tax_terms
  ]); ?>
<?php endif; ?>

<?php if (empty($query)) : ?><?php global $wp_query; ?><?php $query = $wp_query; ?><?php endif; ?><?php if ($query->have_posts()) : ?>
  <section>
    <div class="container space-y-6">
      <?php echo $__env->make('components.section-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 xl:gap-10">
        <?php $i = 1; ?>
          <?php if (empty($query)) : ?><?php global $wp_query; ?><?php $query = $wp_query; ?><?php endif; ?><?php if ($query->have_posts()) : ?><?php while ($query->have_posts()) : $query->the_post(); ?>
            <?php echo $__env->make('components.item-people', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php $i++ ?>
        <?php endwhile; wp_reset_postdata(); endif; ?>
      </div>
    </div>
  </section>
<?php wp_reset_postdata(); endif; ?><?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/lppi/resources/views/partials/list-people.blade.php ENDPATH**/ ?>