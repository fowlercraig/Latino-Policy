<?php extract([
  'title'     => $title ?? 'Recent News & Press',
  'posts'     => $posts ?? false,
  'resource'  => $resource ?? false,
  'tax'       => $tax ?? false,
  'orderby'   => $orderby ?? 'date',
  'post_type' => $post_type ?? 'press',
  'tax'       => $tax ?? false,
]); ?>

<?php $tax_terms = null; ?>

<?php if($tax): ?>
  <?php $tax_terms = array(
    array(
      'taxonomy' => 'issue',
      'field' => 'slug',
      'terms' => $tax,
    )
  ); ?>
<?php endif; ?>

<?php if($resource): ?>
  <?php $tax_terms = array(
    array(
      'taxonomy' => 'resource',
      'field' => 'slug',
      'terms' => $resource,
    )
  ); ?>
<?php endif; ?>

<?php global $query; ?><?php $query = new WP_Query([
  'post_type'       => $post_type,
  'posts_per_page'  => 4,
  'post__in'        => $posts,
  'orderby'         => $orderby,
  'order'           => 'DESC',
  'tax_query'       => $tax_terms
]); ?>

<?php if (empty($query)) : ?><?php global $wp_query; ?><?php $query = $wp_query; ?><?php endif; ?><?php if ($query->have_posts()) : ?>
  <section>
    <div class="container space-y-6">
      <?php echo $__env->make('components.section-header',[
        'title'     => $title,
        'btnLabel'  => 'Visit the Newsroom',
        'btnLink'   => '/newsroom',
      ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="grid sm:grid-cols-2 xl:grid-cols-4 gap-4 md:gap-6 xl:gap-10">
        <?php if (empty($query)) : ?><?php global $wp_query; ?><?php $query = $wp_query; ?><?php endif; ?><?php if ($query->have_posts()) : ?><?php while ($query->have_posts()) : $query->the_post(); ?>
          <?php echo $__env->make('components.item-news', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endwhile; wp_reset_postdata(); endif; ?>
      </div>
    </div>
  </section>
<?php wp_reset_postdata(); endif; ?><?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/lppi/resources/views/partials/list-news.blade.php ENDPATH**/ ?>