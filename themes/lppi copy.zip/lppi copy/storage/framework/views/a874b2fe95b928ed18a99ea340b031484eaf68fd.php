<?php extract([
  'url'     => $url ?? false,
  'desc'    => $desc ?? false,
  'title'   => $title ?? false,
  'cta'     => $cta ?? false,
]); ?>

<section class="space-y-2">
  <div class="<?php if($desc): ?> grid grid-cols-2 gap-4 md:gap-6 xl:gap-10 <?php endif; ?>">
    <div class="prose md:prose-2xl">
      <h2 class="text-brand-dark"><?php echo $title; ?></h2>
    </div>
    <?php if($desc): ?>
      <div class="prose">
        <?php echo $desc; ?>

      </div>
    <?php endif; ?>
  </div>
  <?php if($url): ?>
    <?php echo $__env->make('components.button-animated',[
      'classes' => '', 
      'url'     => $url
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>
</section><?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/latinopolicy/resources/views/components/section-header.blade.php ENDPATH**/ ?>