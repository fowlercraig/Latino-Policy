<?php if(get_field('publication_link')): ?>
  <?php $link = get_field('publication_link')['url']; ?>
  <?php $target = '_blank'; ?>
<?php else: ?>
  <?php $link = get_permalink(); ?>
  <?php $target = '_blank'; ?>
<?php endif; ?>

<article class="space-y-3">
  <a href="<?php echo $link; ?>" class="block relative cursor-pointer">
    <div class="aspect-w-16 aspect-h-9 md:aspect-w-4 md:aspect-h-3 bg-brand-dark relative">
      <div class="absolute inset-0 flex items-center justify-center">
        <?php if(get_the_post_thumbnail()): ?>
          <img src="<?= get_the_post_thumbnail_url(get_the_ID(), 'full'); ?>" alt="<?= get_the_title(); ?>" class="w-full h-full object-cover" />
        <?php else: ?>
          <div class="text-6xl text-brand">
            <i class="far fa-newspaper w-full h-full object-contain"></i>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </a>
  <?php echo $__env->first(['components.eyebrow-'.get_post_type(), 'components.eyebrow'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="prose">
    <h3 class="text-brand-dark"><?= get_the_title(); ?></h3>
    <?php echo $__env->make('components.button-animated',[
      'cta'=>'Read More', 
      'classes'=>'', 
      'url'=> $link
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
</article><?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/lppi/resources/views/components/item-news.blade.php ENDPATH**/ ?>