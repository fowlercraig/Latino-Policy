<form action="/" method="get" class="relative group hidden xl:block">
  <label class="sr-only" for="search">Search in <?php echo e(home_url( '/' )); ?></label>
  <input class="h-7 px-2 rounded border border-black border-opacity-5 text-sm text-gray-600" type="text" name="s" id="search" value="<?php echo e(the_search_query()); ?>" placeholder="Search" />
  <button class="h-7 w-7 flex items-center justify-center absolute top-0 right-0" type="submit">
    <span class="sr-only">Search</span>
    <i height="16px" width="16px" data-feather="search"></i>
  </button>
</form><?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/lppi/resources/views/partials/searchform.blade.php ENDPATH**/ ?>