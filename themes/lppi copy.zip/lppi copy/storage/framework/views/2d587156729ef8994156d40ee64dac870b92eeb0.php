<?php if(!is_tax('role') && !is_archive()): ?>
  <?php if(get_the_post_thumbnail()): ?>
    <div class="md:pt-12 md:-mt-12 bg-brand-dark relative h-32 md:h-header">
      <div class="h-px bg-white opacity-10 relative z-10"></div>
      <div class="absolute inset-0">
        <?php echo wp_get_attachment_image(
                get_post_thumbnail_id(),
                'full',
                false,
                ['alt' => 'Hello','class' => 'w-full h-full object-cover object-center']
            ); ?>
      </div>
      <div class="absolute inset-0 bg-gradient-to-l from-transparent to-black opacity-75"></div>
    </div>
  <?php else: ?>
    <div class="h-px bg-white opacity-10"></div>
  <?php endif; ?>
<?php else: ?>
  <div class="h-px bg-white opacity-10"></div>
<?php endif; ?><?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/latinopolicy/resources/views/partials/page-header-image.blade.php ENDPATH**/ ?>