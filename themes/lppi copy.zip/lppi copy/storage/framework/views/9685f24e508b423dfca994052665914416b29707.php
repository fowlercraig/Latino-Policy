<article <?php (post_class('space-y-5 md:space-y-12 xl:space-y-20')); ?>>
  
  <header class="bg-brand-dark text-brand-lighter md:pt-12 md:-mt-12">
    <div class="h-px bg-white opacity-10"></div>
    <div class="container pt-6 grid lg:grid-cols-2 gap-5 md:gap-10">

      <div class="lg:order-last">
        <div class="shadow-xl">
          <?php echo wp_get_attachment_image(
                get_post_thumbnail_id(),
                'large',
                false,
                ['alt' => ' ','class' => 'w-full h-full object-cover']
            ); ?>
        </div>
      </div>

      <div class="space-y-4 pb-6">
        <?php echo $__env->first(['components.eyebrow-'.get_post_type(), 'components.eyebrow'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="prose prose-sm sm:prose md:prose-lg mx-auto sm:mx-auto">
          <h1 class="tracking-tight text-white">
            <span class="leading-none block"><?php echo $title; ?></span>
          </h1>
        </div>
        <?php echo $__env->make('partials/entry-meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php the_excerpt(); ?>
        <?php echo $__env->first(['components.entry-contributors-'.get_post_type(), 'components.entry-contributors'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('components.entry-downloads', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>

    </div>
  </header>

  <div class="container grid sm:grid-cols-2 gap-5 md:gap-10">
    <div class="prose entry-content max-w-full space-y-4">
      <?php (the_content()); ?>
    </div>
    <div class="prose entry-content max-w-full space-y-10">
      <?php echo $__env->make('partials.research-moreinfo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </div>

  <footer class="space-y-5 md:space-y-12 xl:space-y-20">
    <?php $issues = get_the_terms(get_the_ID(), 'issue'); ?>    
    <?php echo $__env->make('partials.list-research',[
      'title' => 'More on '.$issues[0]->name.' ', 
      'url'   => '/research/',
      'cta'   => 'Visit the Research Library', 
      'posts' => get_field('related_research'),
      'tax'   => $issues[0]->slug
      ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.list-people',[
      'title' =>'Related Experts', 
      'limit' => 4,
      'url'   => '/people/experts/',
      'cta'   => 'More Experts', 
      'posts' => get_field('related_people'), 
      'tax'   => $issues[0]->slug
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.list-news',[
      'title' =>'Related News & Press', 
      'limit' => 4,
      'url'   => '/press-archive',
      'cta'   => 'More Press', 
      'posts' => get_field('related_news'), 
      'tax'   => $issues[0]->slug
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </footer>



</article><?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/lppi/resources/views/partials/content-single-research.blade.php ENDPATH**/ ?>