<div class="people-nav h-12 bg-brand text-white mb-12 flex items-center">
  <div class="container space-x-4 text-sm font-medium">
    <?php if(has_nav_menu('people_navigation')): ?>
      <?php echo wp_nav_menu(['theme_location' => 'people_navigation', 'menu_class' => 'nav flex items-center space-x-4', 'echo' => false]); ?>

    <?php endif; ?>
  </div>
</div><?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/lppi/resources/views/partials/page-header-people.blade.php ENDPATH**/ ?>