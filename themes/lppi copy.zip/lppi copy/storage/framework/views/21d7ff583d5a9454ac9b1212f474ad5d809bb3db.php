<?php global $query; ?><?php $query = new WP_Query([
  'post_type'      => 'page',
  'posts_per_page' => -1,
  'post_parent'    => 3481,
  'order'          => 'ASC',
  'orderby'        => 'menu_order'
]); ?>

<section class="container bg-gray-100 py-4 md:py-12 xl:py-20 space-y-4 md:space-y-6 xl:space-y-10">
  <header>
    <div class="prose prose-sm sm:prose md:prose-2xl">
      <h2 class="text-brand-dark"><?= get_field('work_title'); ?></h2>
      <div class="text-base"><?= get_field('work_description'); ?></div>
    </div>
  </header>
  <div class="">
    <div class="grid lg:grid-cols-2 gap-4 md:gap-6 xl:gap-10">
      <?php if (empty($query)) : ?><?php global $wp_query; ?><?php $query = $wp_query; ?><?php endif; ?><?php if ($query->have_posts()) : ?><?php while ($query->have_posts()) : $query->the_post(); ?>
        <a href="<?= get_permalink(); ?>" class="block p-4 bg-white rounded shadow-sm flex lg:items-center hover:shadow-xl transition ease duration-500">
          <div class="w-1/3 md:w-1/5 flex-none">
            <div class="aspect-w-1 aspect-h-1 relative">
              <div class="absolute inset-0">
                <?php echo $__env->make('components.image',['imageid'=>get_field('icon')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </div>
            </div>
          </div>
          <div class="w-full pl-4 prose md:prose-xl">
            <h4 class="text-brand-dark"><?= get_the_title(); ?></h4>
            <div class="text-sm"><?php the_excerpt(); ?></div>
          </div>
        </a>
      <?php endwhile; wp_reset_postdata(); endif; ?>
    </div>
  </div>
</section><?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/latinopolicy/resources/views/partials/about-work.blade.php ENDPATH**/ ?>