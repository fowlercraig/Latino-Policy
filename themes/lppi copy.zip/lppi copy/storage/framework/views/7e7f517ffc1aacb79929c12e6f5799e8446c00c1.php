<div class="bg-brand h-8 px-3 inline-flex items-center text-white space-x-1 text-xs sm:text-sm font-medium">
  
  <?php if(has_term('','resource')): ?>
    <span class="flex-none"><?php if (get_the_terms(get_the_ID(), 'resource')) : ?><?= collect(get_the_terms(get_the_ID(), 'resource'))->shift()->name; ?><?php endif; ?></span>
    <i class="flex-none" height="16" width="16" data-feather="arrow-right"></i>
  <?php endif; ?>
  <?php if(has_term('','issue')): ?>
    <span class="flex-none"><?php if (get_the_terms(get_the_ID(), 'issue')) : ?><?= collect(get_the_terms(get_the_ID(), 'issue'))->shift()->name; ?><?php endif; ?></span>
  <?php endif; ?>

</div><?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/lppi/resources/views/components/eyebrow.blade.php ENDPATH**/ ?>