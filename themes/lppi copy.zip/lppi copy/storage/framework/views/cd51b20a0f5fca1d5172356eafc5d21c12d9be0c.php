<?php if (get_field('downloads')) : ?>
  <?php echo $__env->make('components.divider',['classes'=>'bg-white opacity-20'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <h3 class="font-medium text-sm text-white opacity-75">Downloads</h3>
  <ul class="grid grid-cols-2 gap-2">
    <?php if (have_rows('downloads')) : ?><?php while (have_rows('downloads')) : the_row(); ?>
      <li>
        <a href="<?= get_sub_field('download')['url']; ?>" class="flex items-center">
          <div class="w-10 h-10 bg-gray-100 text-brand flex-none rounded-full mr-2 flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
          </div>
          <div class="leading-tight text-sm">
            <span class="block font-medium">Download</span>
            <span class="text-xs opacity-50"><?= get_sub_field('download')['title']; ?></span>
          </div>
        </a>
      </li>
    <?php endwhile; endif; ?>
  </ul>
<?php endif; ?><?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/lppi/resources/views/components/entry-downloads.blade.php ENDPATH**/ ?>