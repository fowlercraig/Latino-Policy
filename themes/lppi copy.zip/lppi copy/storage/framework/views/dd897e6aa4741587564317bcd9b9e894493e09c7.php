<div x-data="{ subscribe: false, menu: null }" @keydown.window.escape="menu = false">  

  <a class="sr-only focus:not-sr-only" href="#main">
    <?php echo e(__('Skip to content')); ?>

  </a>

  <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <main id="main" class="max-w-none main text-gray-600 space-y-5 md:space-y-12 xl:space-y-20">
    <?php echo $__env->yieldContent('content'); ?>
  </main>

  <?php if (! empty(trim($__env->yieldContent('sidebar')))): ?>
    <aside class="sidebar">
      <?php echo $__env->yieldContent('sidebar'); ?>
    </aside>
  <?php endif; ?>

  <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/latinopolicy/resources/views/layouts/app.blade.php ENDPATH**/ ?>