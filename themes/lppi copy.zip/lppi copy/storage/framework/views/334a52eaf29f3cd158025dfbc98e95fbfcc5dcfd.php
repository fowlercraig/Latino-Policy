<article class="text-white bg-black relative group lg:h-full lg:min-h-[400px]" data-aos="fade-up">
  <div class="bg-black relative transform transition ease-in-out duration-500 hover:-translate-y-1 h-full relative">
    <div class="absolute inset-0 opacity-50 group-hover:opacity-25 transition ease-in-out duration-500">
      <?php if(get_the_post_thumbnail()): ?>
        <img src="<?= get_the_post_thumbnail_url(get_the_ID(), 'full'); ?>" alt="<?= get_the_title(); ?>" class="w-full h-full object-cover" />
      <?php else: ?>
        <div class="text-6xl text-brand">
          <i class="far fa-newspaper w-full h-full object-contain"></i>
        </div>
      <?php endif; ?>
    </div>
    <div class="relative flex flex-col px-4 md:px-6 xl:px-10 h-full">
      <div><?php echo $__env->first(['components.eyebrow-'.get_post_type(), 'components.eyebrow'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
      <div class="mt-4">
        <h2 class="tracking-tight font-bold text-2xl xl:text-4xl leading-none font-primary-a uppercase"><?= get_the_title(); ?></h2>
      </div>
      <div class="flex-1 min-h-[50px]"></div>
      <div class="pb-4 md:pb-6 xl:pb-8">
        <?php echo $__env->make('components.button-animated-top',[
          'cta'=>'Learn More', 
          'classes'=>'text-white', 
          'url'=> get_permalink()
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>
  </div>
  <a href="<?= get_permalink(); ?>" title="<?= get_the_title(); ?>" class="absolute inset-0"></a>
</article>
<?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/lppi/resources/views/components/item-research.blade.php ENDPATH**/ ?>