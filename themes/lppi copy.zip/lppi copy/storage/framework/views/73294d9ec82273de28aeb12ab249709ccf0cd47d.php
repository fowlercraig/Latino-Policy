<?php if (get_field('moreinfo')) : ?>
  <div>
    <h3>Additional Content</h3>
    <div>
      <?php if (have_rows('moreinfo')) : ?><?php while (have_rows('moreinfo')) : the_row(); ?>
        <div class="grid grid-cols-3 gap-6 p-4 shadow rounded">
          <div class="col-span-1">
            <div class="aspect-w-4 aspect-h-3 bg-gray-100 relative">
              <div class="absolute inset-0">
                <?php $image = get_sub_field('image'); ?>
                <?php echo wp_get_attachment_image(
                $image,
                'medium',
                false,
                ['alt' => 'My alt tag','class' => 'block w-full h-full object-cover nomargin']
            ); ?>
              </div>
            </div>
          </div>
          <div class="col-span-2 prose prose-sm">
            <h3><?= get_sub_field('title'); ?></h3>
            <div><?= get_sub_field('description'); ?></div>
            <a href="<?= get_sub_field('link')['url']; ?>">
              <span class="underline"><?= get_sub_field('link')['title']; ?></span>
            </a>
          </div>
        </div>
      <?php endwhile; endif; ?>
    </div>
  </div>
<?php endif; ?><?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/lppi/resources/views/partials/research-moreinfo.blade.php ENDPATH**/ ?>