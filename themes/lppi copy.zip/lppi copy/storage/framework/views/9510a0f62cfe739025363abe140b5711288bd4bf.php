<div <?php echo e($attributes->merge(['class' => $type])); ?>>
  <div class="px-4 py-3">
    <?php echo $message ?? $slot; ?>

  </div>
</div>
<?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/lppi/resources/views/components/alert.blade.php ENDPATH**/ ?>