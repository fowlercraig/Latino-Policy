<?php global $cookie; ?>
<?php if($cookie): ?>
  <?php $modalState = 'false'; ?>
<?php else: ?>
  <?php $modalState = 'true'; ?>
<?php endif; ?>

<div x-data="{ subscribe: <?php echo e($modalState); ?>, menu: null }" @keydown.window.escape="menu = false" @mouseleave="setTimeout(() => menu = false, 100)">

  <a class="sr-only focus:not-sr-only" href="#main">
    <?php echo e(__('Skip to content')); ?>

  </a>

  <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main id="main" class="max-w-none main text-gray-600">
      <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php if (! empty(trim($__env->yieldContent('sidebar')))): ?>
      <aside class="sidebar">
        <?php echo $__env->yieldContent('sidebar'); ?>
      </aside>
    <?php endif; ?>

  <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/lppi/resources/views/layouts/home.blade.php ENDPATH**/ ?>