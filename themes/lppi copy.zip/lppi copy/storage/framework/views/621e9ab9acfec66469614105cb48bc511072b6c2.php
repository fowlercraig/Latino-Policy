<div>
  <time class="updated" datetime="<?php echo e(get_post_time('c', true)); ?>">
    <div class="flex items-center space-x-1">

      <?php if(!is_singular('event')): ?>
        <span>Published</span> 
        <i height="16" width="16" data-feather="arrow-right"></i>
        <span><?= get_the_date(); ?></span>
      <?php else: ?>
        <span>Event Date</span> 
        <i height="16" width="16" data-feather="arrow-right"></i>
        <span><?= get_field('date'); ?></span>
      <?php endif; ?>

    </div>
  </time>
</div>

<?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/lppi/resources/views/partials/entry-meta.blade.php ENDPATH**/ ?>