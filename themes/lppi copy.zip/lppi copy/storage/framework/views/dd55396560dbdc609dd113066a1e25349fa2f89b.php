<?php $menuLocations = get_nav_menu_locations(); ?>
<?php $menuID = $menuLocations['social_navigation']; ?>
<?php $primaryNav = wp_get_nav_menu_items($menuID); ?>

<footer class="content-info text-gray-600 py-4 md:py-12 xl:py-20">
  <div class="container bg-brand-lightest md:flex py-4 md:py-12 xl:py-20">
    <div class="space-y-4 w-full md:w-1/3 flex-none">
      <?php echo e(get_svg('images/Bxd_Blk_LPPI_Luskin_D.svg', 'h-10 sm:h-10 w-auto', ['aria-label' => $siteName])); ?>
      <p class="font-bold font-primary-a text-brand-dark uppercase tracking-tighter text-3xl">
        <?php echo e(bloginfo('description')); ?>

      </p>
      <?php if(has_nav_menu('social_navigation')): ?>
        <ul class="flex items-center space-x-4 text-brand">
          <?php $__currentLoopData = $primaryNav; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $navItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
              <a class="text-xl" target="_blank" href="<?php echo e($navItem->url); ?>" title="<?php echo e($navItem->title); ?>">
                <i class="fab fa-<?php echo e(strtolower($navItem->title)); ?>"></i>
                <span class="sr-only"><?php echo e($navItem->title); ?></span>
              </a>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      <?php endif; ?>
    </div>
    <div class="w-full md:pl-10 grid md:grid-cols-2 xl:grid-cols-3 gap-4 md:gap-6 xl:gap-10">
      <?php (dynamic_sidebar('sidebar-footer')); ?>
    </div>
  </div>
</footer>
<div class="hidden leading-snug aspect-w-7 aspect-h-5"></div><?php /**PATH /Users/craigfowler/Sites/latino.ucla.dev.cc/wp-content/themes/lppi/resources/views/partials/footer.blade.php ENDPATH**/ ?>