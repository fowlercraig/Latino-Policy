<a href="{!! $link !!}">
  <span class="sr-only">{{ $title }}</span>
  <i height="20px" width="20px" data-feather="{{ $title }}"></i>
</a>