@extract([
  'classes' => $classes ?? 'bg-gray-100',
])

<hr class="border-0 h-px {{ $classes }}" />