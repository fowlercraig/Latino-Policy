<section>
  <div class="container">
    <div class="prose lg:prose-xl mx-auto text-center">
      <h1 class="text-brand leading-none">@option('headline')</h1>
      @include('components.subscribe-form')
    </div>
  </div>
</section>