<article @php(post_class('space-y-5 md:space-y-12 xl:space-y-20'))>
  <div class="bg-brand-dark text-brand-lighter md:pt-12 md:-mt-12 ">
    <div class="h-px bg-white opacity-10"></div>
    <header class="container py-6">
      <div class="space-y-4">
        <h1 class="tracking-tight font-bold text-4xl sm:text-5xl text-white">{!! $title !!}</h1>
      </div>
    </header>
  </div>  
</article>
