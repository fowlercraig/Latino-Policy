<?php return array (
  'log1xnavi' => 
  array (
    'providers' => 
    array (
      0 => 'Log1x\\Navi\\Providers\\NaviServiceProvider',
    ),
    'aliases' => 
    array (
      'Navi' => 'Log1x\\Navi\\Facades\\Navi',
    ),
  ),
  'log1xpoet' => 
  array (
    'providers' => 
    array (
      0 => 'Log1x\\Poet\\PoetServiceProvider',
    ),
  ),
  'log1xsage-svg' => 
  array (
    'providers' => 
    array (
      0 => 'Log1x\\SageSvg\\SageSvgServiceProvider',
    ),
  ),
);