<div class="font-medium">
  <span>Issues</span>
  <span class="text-white-75">→</span>
  <span>@terms('issue')</span>
</div>