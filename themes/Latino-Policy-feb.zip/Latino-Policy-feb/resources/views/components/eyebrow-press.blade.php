<div class="bg-brand h-8 px-3 inline-flex items-center text-white space-x-1 text-xs sm:text-sm font-medium">
  
  @if(has_term('','issue'))
    <span>@term('issue')</span>
  @else
    <span>News &amp; Press</span>
  @endif

</div>