<div class="titles">
@hasfield('title')
<div class="font-medium">@field('title')</div>
@endfield

@hasfield('affiliation')
<div class="font-medium">@field('affiliation')</div>
@endfield

@hasfield('association')
<div class="font-medium">@field('association')</div>
@endfield
</div>