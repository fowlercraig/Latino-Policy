<article @php(post_class('space-y-5 md:space-y-12 xl:space-y-20'))>
  


</article>