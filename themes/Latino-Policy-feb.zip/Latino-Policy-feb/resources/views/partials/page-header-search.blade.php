@global($post)
<div class="md:pt-12 md:-mt-12 bg-brand-dark">
  <div class="page-header text-white py-4 md:py-4">
    <div class="container">
      <h1 class="tracking-tight font-bold text-4xl md:text-6xl xl:text-7xl font-primary-a uppercase">{!! $title !!}</h1>
    </div>
  </div>
</div>